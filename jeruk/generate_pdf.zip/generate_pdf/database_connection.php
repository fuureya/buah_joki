<?php
$hostname = "localhost";
$username = "root";
$password = "";  
$database = "shinerweb_db";   
$con=mysqli_connect($hostname,$username,$password,$database);    
?>   